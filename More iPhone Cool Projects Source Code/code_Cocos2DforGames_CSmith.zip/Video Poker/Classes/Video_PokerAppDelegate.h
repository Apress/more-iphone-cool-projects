//
//  Video_PokerAppDelegate.h
//  Video Poker
//
//  Created by Chuck Smith on 3/6/10.
//  Copyright Chuck Smith 2010. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Video_PokerAppDelegate : NSObject <UIApplicationDelegate> {
	UIWindow *window;
}

@property (nonatomic, retain) UIWindow *window;

@end
