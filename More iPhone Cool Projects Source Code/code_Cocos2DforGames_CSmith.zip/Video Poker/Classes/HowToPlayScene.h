//  HowToPlayScene.h
//  Video Poker

#import "cocos2d.h"


@interface HowToPlay : CCLayer {

}

+(id) scene;

@end
