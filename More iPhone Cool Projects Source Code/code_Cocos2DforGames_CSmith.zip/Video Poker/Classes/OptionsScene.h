//
//  OptionsScene.h
//  Video Poker
//
//  Created by Chuck Smith on 1/29/10.
//  Copyright 2010 Chuck Smith. All rights reserved.
//

#import "cocos2d.h"


@interface Options : CCLayer {

}

+(id) scene;

@end
