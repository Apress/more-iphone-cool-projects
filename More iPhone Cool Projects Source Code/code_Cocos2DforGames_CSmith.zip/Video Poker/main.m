//
//  main.m
//  Video Poker
//
//  Created by Chuck Smith on 3/20/10.
//  Copyright Chuck Smith 2010. All rights reserved.
//

#import <UIKit/UIKit.h>

int main(int argc, char *argv[]) {
	NSAutoreleasePool *pool = [NSAutoreleasePool new];
	int retVal = UIApplicationMain(argc, argv, nil, @"Video_PokerAppDelegate");
	[pool release];
	return retVal;
}
