//
//  main.m
//  HelloOperationQueues
//
//  Created by Danton Chin on 3/28/10.
//  Copyright  http://iphonedeveloperjournal.com/ 2010. All rights reserved.
//

#import <UIKit/UIKit.h>

int main(int argc, char *argv[]) {
    
    NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
    int retVal = UIApplicationMain(argc, argv, nil, nil);
    [pool release];
    return retVal;
}
